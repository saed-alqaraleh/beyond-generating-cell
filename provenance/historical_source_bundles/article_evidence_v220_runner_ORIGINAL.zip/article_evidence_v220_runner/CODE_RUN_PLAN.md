# Code-first execution plan

1. Validate the immutable repaired core hash.
2. Run all code/synthetic tests and save `TEST_REPORT`.
3. Content-fingerprint the real `cells/` and `poses/` trees once.
4. Verify the five existing successful jobs by marker + manifest hashes + embedded results.
5. Schedule only missing or failed-verification work.
6. Track 0: full 15-alpha primary template analysis + theta=90.
7. Track 1: theta=90 ambiguity for scenes 0002, 0003, 0004.
8. If any of the five prior jobs fails verification, rerun only that job under v2.2.0.
9. Finalize uniform theta, four-scene, color, template, and integrity evidence.
10. Return the final evidence ZIP for the later article-number audit. Do not edit the article before that audit passes.
