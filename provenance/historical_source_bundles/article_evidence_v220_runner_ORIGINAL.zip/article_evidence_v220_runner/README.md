# Article evidence runner for kpose_diagnostics v2.2.0

This package is the **code/results phase only**. It does not edit `manuscript_v10.tex` and it intentionally does not create the final `ARTICLE_*` manuscript-number audit yet. The article audit is performed only after the real evidence archive has been generated and returned.

## Scientific rule: the validated core is immutable

The embedded source archive is the user-supplied repaired package. Its required source-tree hash is:

`b6519535a7778530ee4ddc30ede8ef9659d76fa0dbe072f22de28c3c407f0a2c`

The article runner imports that code read-only. New orchestration and the full manuscript alpha analysis live under `article_evidence/`, outside the core tree, so the five completed v2.2.0 jobs can remain reusable under the same core hash.

Expected content fingerprints of the real dataset are:

- cells tree: `28ae56bbff5cc0fde8e0549c3820a2908c049a9ec402f22b83ebb61bb3bdf503`
- poses tree: `141c5402bd261d2c1352804f838075dcc12ea795619b3a77f605751334988f41`

The plan stops if either content fingerprint differs.

## Existing jobs: verify, do not rerun blindly

The following jobs are first checked against `MANIFEST.json`, `_JOB_DONE.json`, the embedded `MERGED_RESULTS.json` object, core hash, input fingerprint, and required output files:

- `kpose_2013_05_28_drive_0000_sync`
- `kpose_color`
- `theta_45`
- `theta_22.5`
- `theta_10`

A verified job is copied into the evidence run and is **not executed again**. A job is scheduled for rerun only if verification fails.

## Missing scientific work performed by this runner

1. `theta_90`, using `reference_mode=off`, exactly matching the mode already used for 45, 22.5 and 10 degrees. The registered theta=90 reference is checked independently afterward, so non-90 theta values are never misclassified against a 90-degree reference.
2. Theta=90 template ambiguity for scenes `0002`, `0003`, and `0004`, plus the primary scene from the same v2.2.0 result chain.
3. Full primary template-query analysis using **all manuscript-declared alpha values**:
   `0, .1, .2, .3, .4, .5, .6, .7, .8, .85, .9, .95, .98, .99, 1.0`.
4. Full T1/T2 arrays, source-cell clustered 95% bootstrap intervals (`B=2000`), tie fraction and tied-set size, all pairwise alpha bootstrap comparisons, the four manuscript permutation contrasts (`10,000` permutations), exact V distribution, ambiguity strata, generating-cell validity, chance/ceiling baselines, alpha=.4 outcome classification, semantic-label counts, and a reproducible 500-query rank sample at alpha=.5.
5. Direct no-color vs color descriptive table from the accepted KPOSE description results, including agreement, V, R/CI, recoverable ceiling, region area, oracle recall@5/10/15 m, and convergence status.
6. Scientific integrity checks and all required core/executor tests.

### Rank-sample seed

The manuscript declares a random sample of 500 queries but does not declare its seed. This runner fixes seed `20260808` and saves the exact sampled query indices. If those ranks differ from manuscript values, the later audit must mark the manuscript values as a mismatch rather than tuning the seed to reproduce them.

## Theta identity that must not be silently changed

The manuscript/core definition is:

- theta=90 degrees = support of the half-plane `S_dir > 0` rule;
- theta=45 degrees = dominant-axis cone.

The earlier request to check “theta=90 equivalence with the dominant-axis rule” conflicts with that definition. The final integrity report keeps this conflict visible. It does **not** alter the predicate to make an incorrect identity pass.

## Resume model

- `PLAN.json` is generated once by Track 0.
- Track 0 and Track 1 write to separate `tracks/track0/` and `tracks/track1/` directories.
- Every completed job has `_JOB_DONE.json` with a signature based on the job specification, core hash, executor hash and input fingerprint.
- Custom template relation-score work is split into atomic 50-cell checkpoints. On interruption, completed chunks are reused.
- Core parsed-scene caches are persistent per track.
- All JSON/CSV/NPZ final writes in the executor are atomic.
- No scientific job uses `--skip-gate`.

## Recommended Colab execution

Use the supplied notebooks:

- `colab/ARTICLE_EVIDENCE_v2.2.0_TRACK_0.ipynb`
- `colab/ARTICLE_EVIDENCE_v2.2.0_TRACK_1.ipynb`

Upload this runner ZIP once to:

`MyDrive/or_fusion_verification/article_evidence_v220_runner.zip`

The notebooks assume:

- dataset: `MyDrive/or_fusion_verification/data/k360_30-10_scG_pd10_pc4_spY_all`
- existing five-job results: `MyDrive/or_fusion_verification/results_kpose_v220_repaired`
- new durable output: `MyDrive/or_fusion_verification/article_evidence_v220`

Run Track 0 through **tests + PLAN** first. Then start Track 1. Both tracks may run simultaneously after the plan exists.

## Commands

After the runner and embedded core are extracted and on `PYTHONPATH`:

```bash
python -m article_evidence.runner tests \
  --out <OUT> --core-root <CORE_ROOT>

python -m article_evidence.runner plan \
  --base <DATASET_ROOT> \
  --existing <EXISTING_V220_RESULTS> \
  --core-root <CORE_ROOT> \
  --out <OUT>

python -m article_evidence.runner run-track --out <OUT> --track 0
python -m article_evidence.runner run-track --out <OUT> --track 1
python -m article_evidence.runner status --out <OUT>

python -m article_evidence.runner finalize \
  --out <OUT> \
  --core-archive <kpose_diagnostics_v2.2.0_repaired.zip> \
  --executor-archive <article_evidence_v220_runner.zip>
```

## Required tests

The `tests` command runs and saves:

- `python -m compileall -q .`
- `python -m kpose_diagnostics.tests.test_core`
- `python -m kpose_diagnostics.tests.smoke_test`
- `python -m kpose_diagnostics.tests.kpose_predicate_e2e`
- `python -m unittest -v kpose_diagnostics.tests.test_regressions_v220`
- `python -m unittest -v article_evidence.tests.test_executor`

## Final evidence products after the real run

`<OUT>/FINAL_EVIDENCE/` contains the exact core source archive, executor archive, all canonical job outputs, result JSONs, per-query/per-description arrays, per-job logs, consolidated CSV tables, `RUN_SUMMARY.txt`, embedded `MERGED_RESULTS.json`, `PLAN.json`, `TEST_REPORT.*`, scientific-integrity checks, input fingerprint, and `MANIFEST.json`.

The final ZIP is created inside `<OUT>`:

`<OUT>/article_evidence_v220_FINAL_EVIDENCE_v2.2.0.zip`

`ARTICLE_RESULTS_REQUIREMENTS.json`, `ARTICLE_NUMBERS_AUDIT.csv`, and `ARTICLE_RESULTS_AUDIT.md` are deliberately deferred until this real archive is available, in accordance with the instruction to finish the code/results phase first.
